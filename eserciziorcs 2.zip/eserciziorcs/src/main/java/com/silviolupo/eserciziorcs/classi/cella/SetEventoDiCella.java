package com.silviolupo.eserciziorcs.classi.cella;


import com.silviolupo.eserciziorcs.classi.cella.EventoDiCella;

import java.util.*;

public class SetEventoDiCella {
	
	private List<EventoDiCella> lista;
	private static Integer PRIMA_OCCORRENZA = new Integer(1);
		
	public SetEventoDiCella(List<EventoDiCella> lista) {
		this.lista = lista;
	}

	public List<String> ordinaCelleMedianteFrequenza(){
		Iterator<EventoDiCella> iteraCellEvent = this.lista.iterator();
		Map<String, Integer> mappa = new TreeMap<String, Integer>();
		while(iteraCellEvent.hasNext()) {
			EventoDiCella tmp = iteraCellEvent.next();
			if(mappa.containsKey(tmp)) {
				mappa.put(tmp.getNome(), mappa.get(tmp.getNome())+1);
			}else {
				mappa.put(tmp.getNome(), PRIMA_OCCORRENZA);
			}
		}
		List<String> sortedKeys = new ArrayList<>(mappa.keySet());
		Collections.sort(sortedKeys);
		Collections.reverse(sortedKeys);
		return sortedKeys;
	}
}

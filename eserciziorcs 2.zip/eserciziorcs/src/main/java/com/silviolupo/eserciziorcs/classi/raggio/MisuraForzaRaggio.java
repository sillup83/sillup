package com.silviolupo.eserciziorcs.classi.raggio;

import com.silviolupo.eserciziorcs.classi.cella.MisuraForza;
import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;

public class MisuraForzaRaggio implements MisuraForza {

	private MisuraForza origine;
	private Raggio raggio;

	public MisuraForzaRaggio(MisuraForza misura, Raggio raggio) {
		this.origine = misura;
		this.raggio = raggio;
	}

	public double calcola(Coordinata coordinata) {
		double risultato = 0.d;
		double distanza  = this.origine.calcola(coordinata);
		if(distanza >= this.raggio.getValore()) {
			risultato = 0;
		}else {
			risultato = (1 - (distanza/this.raggio.getValore())) *100.0d;
		}
		return risultato;
	}
}

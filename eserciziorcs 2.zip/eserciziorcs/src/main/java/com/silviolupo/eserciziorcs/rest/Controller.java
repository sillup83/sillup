package com.silviolupo.eserciziorcs.rest;

import com.silviolupo.eserciziorcs.classi.cella.*;
import com.silviolupo.eserciziorcs.classi.Tipologia;
import com.silviolupo.eserciziorcs.classi.potenza.MisuraForzaPotenza;
import com.silviolupo.eserciziorcs.classi.potenza.Potenza;
import com.silviolupo.eserciziorcs.classi.raggio.MisuraForzaRaggio;
import com.silviolupo.eserciziorcs.classi.raggio.Raggio;
import com.silviolupo.eserciziorcs.classi.ubicazione.Latitudine;
import com.silviolupo.eserciziorcs.classi.ubicazione.Longitudine;
import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@org.springframework.stereotype.Controller
public class Controller {

		private final Logger logger = LogManager.getLogger(this.getClass());

		
		@GetMapping("/ordinaCelleTramiteFrequenzaDiscendente")
		public ResponseEntity<List<String>> ordinaCelleTramiteFrequenzaDiscendente(){
			 ResponseEntity<List<String>> res = null;
			 try {
				List<EventoDiCella> list = new ArrayList<EventoDiCella>();

				Longitudine longitude1 = new Longitudine(9.0756298d);
				Latitudine latitude1 = new Latitudine(45.4616873d);
				Coordinata point1 = new Coordinata(longitude1,latitude1);
				Cella cell1 = new Cella("cell1",point1);
				EventoDiCella ce1 = new EventoDiCella(cell1, LocalDateTime.now(), Tipologia.CONNESSO);

				Longitudine longitude2 = new Longitudine(1.2345690d);
				Latitudine latitude2 = new Latitudine(1.1234567d);
				Coordinata point2 = new Coordinata(longitude2,latitude2);
				Cella cell2 = new Cella("cell2",point2);
				EventoDiCella ce2 = new EventoDiCella(cell2, LocalDateTime.now(), Tipologia.CONNESSO);

				Longitudine longitude3 = new Longitudine(5.2345655d);
				Latitudine latitude3 = new Latitudine(8.1234561d);
				Coordinata point3 = new Coordinata(longitude3,latitude3);
				Cella cell3 = new Cella("cell3",point3);
				EventoDiCella ce3 = new EventoDiCella(cell3, LocalDateTime.now(), Tipologia.DISCONNESSO);

				list.add(ce1);
				list.add(ce2);
				list.add(ce3);

				SetEventoDiCella setCellEvent = new SetEventoDiCella(list);
				res = ResponseEntity.ok(setCellEvent.ordinaCelleMedianteFrequenza());
			} catch (Exception e) {
				logger.error("ordinaCelleTramiteFrequenzaDiscendente():" + e.getMessage());
			}
			return res;
		}

		@PutMapping("/celleConForzaMaggioreDiUnValore")
		public ResponseEntity<List<MisuraForza>> celleConForzaMaggioreDiUnValore(
				@RequestParam Double soglia
				, @RequestBody Coordinata coordinata ){
			 ResponseEntity<List<MisuraForza>> res = null;
			 try {

				 MisuraForza misuraForzaRaggio = new MisuraForzaRaggio(new Cella("cell2"
						 , new Coordinata(new Longitudine(9.0961433), new Latitudine(45.4732446) ) )
						 , new Raggio(10d));

				 MisuraForza misuraForzaPotenza = new MisuraForzaPotenza(new Cella("Cella"
						 ,new Coordinata(
						 new Longitudine(9.0756298), new Latitudine(45.4616873)))
						 , new Potenza(1.25)
				 );

				List<MisuraForza> list = new ArrayList<MisuraForza>();
				list.add(misuraForzaRaggio);
				list.add(misuraForzaPotenza);
				SetCelle setCell = new SetCelle(list, coordinata);
				res = ResponseEntity.ok(setCell.filtraCellaPiuForteDi(soglia));
			} catch (Exception e) {
				logger.error("celleConForzaMaggioreDiUnValore("+ soglia + ", " + coordinata+"):"+e.getMessage());
			}
			return res;
		}

}



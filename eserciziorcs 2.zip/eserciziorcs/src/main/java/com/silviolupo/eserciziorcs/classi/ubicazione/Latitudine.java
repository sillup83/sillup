package com.silviolupo.eserciziorcs.classi.ubicazione;

import lombok.Getter;

public class Latitudine {

	// latitudine: si tratta di un valore numerico che rappresenta la distanza angolare di un punto
	// dall’Equatore, che ha latitudine 0°.
	// Come si fa a capire la latitudine del posto in cui ci si trova?
	// Basta osservare l’altezza della stella polare rispetto al punto di osservazione.
	// Essa coincide sempre con la latitudine; rispetto all’Equatore, che ha latitudine pari a 0°,
	// il Polo Nord si trova a +90° mentre il Polo Sud a -90°.

	private static final double VALORE_MINIMO_LATITUDINE = -90;
	private static final double VALORE_MASSIMO_LATITUDINE = 90;
	@Getter
	private final double valore;

	public Latitudine(double valore) {
		if(valore < VALORE_MINIMO_LATITUDINE || valore > VALORE_MASSIMO_LATITUDINE) {
			throw new IllegalArgumentException(
					String.format(
					"Il valore della latitudine inserito : [%f] non è valido, deve essere compreso tra %f e %f"
							, valore
							, VALORE_MINIMO_LATITUDINE
							, VALORE_MASSIMO_LATITUDINE )
					);
		}
		this.valore = valore;
	}
}

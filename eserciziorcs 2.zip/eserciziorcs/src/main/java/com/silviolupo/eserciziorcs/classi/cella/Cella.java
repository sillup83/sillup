package com.silviolupo.eserciziorcs.classi.cella;

import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;
import lombok.Getter;

public class Cella implements MisuraForza {

	@Getter
	private String nome;
	@Getter
	private Coordinata centro;
	
	public Cella(String nome, Coordinata centro) {
		this.nome = nome;
		this.centro = centro;
	}

	public double calcola(Coordinata coordinata) {
		return this.getCentro().calcolaDistanza(coordinata);
	}
}

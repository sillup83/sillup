package com.silviolupo.eserciziorcs.classi.raggio;

import lombok.Getter;

public class Raggio {

	@Getter
	private double valore;

	public Raggio(double valore) {
		this.valore = valore;
	}
}

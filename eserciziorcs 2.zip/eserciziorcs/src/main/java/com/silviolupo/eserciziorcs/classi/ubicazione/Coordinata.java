package com.silviolupo.eserciziorcs.classi.ubicazione;

import lombok.Getter;

public class Coordinata {

	@Getter
	private Longitudine longitudine;
	@Getter
	private Latitudine latitudine;
	private final static double RAGGIO_MEDIO_DELLA_TERRA_IN_KM = 6371;

	public Coordinata(Longitudine longitudine, Latitudine latitudine) {
		this.longitudine = longitudine;
		this.latitudine = latitudine;
	}

	public double calcolaDistanza(Coordinata coordinata) {
		double latitudineDistanza = Math.toRadians(this.getLatitudine().getValore() - coordinata.getLatitudine().getValore());
		double longitudineDistanza = Math.toRadians(this.getLongitudine().getValore() - coordinata.getLongitudine().getValore());

		double a = Math.sin(latitudineDistanza / 2) * Math.sin(latitudineDistanza / 2)
				+ Math.cos(Math.toRadians(this.getLatitudine().getValore()))
						* Math.cos(Math.toRadians(coordinata.getLatitudine().getValore())) * Math.sin(longitudineDistanza / 2)
						* Math.sin(longitudineDistanza / 2);

		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

		return (int) (Math.round(RAGGIO_MEDIO_DELLA_TERRA_IN_KM * c));
	}

}

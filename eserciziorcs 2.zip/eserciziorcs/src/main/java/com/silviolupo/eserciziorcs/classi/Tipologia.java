package com.silviolupo.eserciziorcs.classi;

public enum Tipologia {
	CONNESSO,
	DISCONNESSO
	;

}

package com.silviolupo.eserciziorcs.classi.cella;

import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SetCelle {

	private List<MisuraForza> setCelle;
	
	private Coordinata coordinata;

	public SetCelle(List<MisuraForza> setCells, Coordinata aPoint) {
		this.setCelle = setCells;
		this.coordinata = aPoint;
	}
	
	
	public List<MisuraForza> filtraCellaPiuForteDi(double sogliaForza){
			final Coordinata coordinata = this.coordinata;
			List<MisuraForza> res = this.setCelle
			.stream()
			.filter(c -> c.calcola(coordinata)  > sogliaForza)
			.collect(Collectors.toList())
			;
			return res;
	}
	
	
	public MisuraForza max(){
		final Coordinata point = this.coordinata;
		 MisuraForza max = this.setCelle
		.stream()
		.max(new Comparator<MisuraForza>() {

			@Override
			public int compare(MisuraForza o1, MisuraForza o2) {
				double res1 = o1.calcola(point);
				double res2 = o2.calcola(point);
				int res = 0;
				if( res1 > res2) {res = 1;}
				else if( res1 < res2) {res = -1;}
				return res ;
			}
			
		}).orElseThrow(RuntimeException::new);
		return max;
	}
	public MisuraForza min(){
		final Coordinata coordinata = this.coordinata;
		 MisuraForza min = this.setCelle
		.stream()
		.min(new Comparator<MisuraForza>() {

			@Override
			public int compare(MisuraForza o1, MisuraForza o2) {
				double res1 = o1.calcola(coordinata);
				double res2 = o2.calcola(coordinata);
				int res = 0;
				if( res1 > res2) {res = 1;}
				else if( res1 < res2) {res = -1;}
				return res ;
			}
			
		}).orElseThrow(RuntimeException::new);
		return min;
	}
	
}

package com.silviolupo.eserciziorcs.classi.potenza;

import lombok.Getter;

public class Potenza {

	@Getter
	private final double valore;

	public Potenza(double valore) {
		this.valore = valore;
	}
}

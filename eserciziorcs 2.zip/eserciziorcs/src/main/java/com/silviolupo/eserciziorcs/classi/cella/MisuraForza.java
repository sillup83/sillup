package com.silviolupo.eserciziorcs.classi.cella;

import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;

public interface MisuraForza {

	public double calcola(Coordinata coordinata);

}

package com.silviolupo.eserciziorcs.classi.cella;

import com.silviolupo.eserciziorcs.classi.Tipologia;
import java.time.LocalDateTime;

public class EventoDiCella {

	private Cella cella;
	
	private LocalDateTime timestamp;
	
	private Tipologia tipologia;

	public EventoDiCella(Cella cella, LocalDateTime timestamp, Tipologia tipologia) {
		this.cella = cella;
		this.timestamp = timestamp;
		this.tipologia = tipologia;
	}

	public String getNome() {
		return this.cella.getNome();
	}
	
}

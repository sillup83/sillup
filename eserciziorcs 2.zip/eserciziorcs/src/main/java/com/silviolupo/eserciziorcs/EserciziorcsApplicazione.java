package com.silviolupo.eserciziorcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EserciziorcsApplicazione {

	public static void main(String[] args) {
		SpringApplication.run(EserciziorcsApplicazione.class, args);
	}

}

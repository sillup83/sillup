package com.silviolupo.eserciziorcs.classi.ubicazione;

import lombok.Getter;

public class Longitudine {
	
	// longitudine: questo valore numerico indica la distanza angolare di un punto dal Meridiano 0,
	// altrimenti chiamato Meridiano di Greenwich o Meridiano fondamentale.
	// A destra di Greenwich ci sono le Longitudini est mentre a sinistra ci sono le Longitudini Ovest.
	// Come si può determinare la longitudine? Ogni quattro minuti la Terra percorre un grado.
	// Se l’ora del posto in cui siamo è superiore rispetto all’ora di Greenwich,
	// allora ci troviamo ad una longitudine est; per contro,
	// se l’orario del luogo in cui siamo è minore siamo a ovest rispetto al meridiano fondamentale.
	// Per indicare la longitudine si parte dal meridiano di Greenwich e si conta da 0° a 180°
	// aggiungendo al numero E (est), che significa che il punto misurato si trova a est del meridiano
	// di Greenwich, oppure O (ovest), che significa che il punto è collocato a ovest del meridiano
	// di riferimento.

	private static final double VALORE_MINIMO_LONGITUDINE = -180d;
	private static final double VALORE_MASSIMO_LONGITUDINE = 180d;
	@Getter
	private final double valore;

	public Longitudine(double valore) {
		if(valore<VALORE_MINIMO_LONGITUDINE || valore>VALORE_MASSIMO_LONGITUDINE) {
			throw new IllegalArgumentException(
					String.format(
					"Il valore delle longitudine inserito [%f] non è valido, deve essere compreso tra %f e %f"
							, valore
							, VALORE_MINIMO_LONGITUDINE
							, VALORE_MASSIMO_LONGITUDINE)
					);
		}
		this.valore = valore;
	}
}

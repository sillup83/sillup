package com.silviolupo.eserciziorcs.classi.potenza;




import com.silviolupo.eserciziorcs.classi.cella.MisuraForza;
import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;

public class MisuraForzaPotenza implements MisuraForza {

	private final MisuraForza origine;
	private final Potenza potenza;

	public MisuraForzaPotenza(MisuraForza misura, Potenza nuovaPotenza) {
		this.origine = misura;
		this.potenza = nuovaPotenza;
	}

	public double calcola(Coordinata coordinata) {
		double distanza = this.origine.calcola(coordinata);
		double risultato = Math.pow(this.potenza.getValore(), distanza);
		return Math.pow(risultato, -1)*100;
	}
}

package com.silviolupo.eserciziorcs;

import com.silviolupo.eserciziorcs.classi.Tipologia;
import com.silviolupo.eserciziorcs.classi.cella.Cella;
import com.silviolupo.eserciziorcs.classi.cella.EventoDiCella;
import com.silviolupo.eserciziorcs.classi.cella.MisuraForza;
import com.silviolupo.eserciziorcs.classi.cella.SetEventoDiCella;
import com.silviolupo.eserciziorcs.classi.potenza.MisuraForzaPotenza;
import com.silviolupo.eserciziorcs.classi.potenza.Potenza;
import com.silviolupo.eserciziorcs.classi.raggio.MisuraForzaRaggio;
import com.silviolupo.eserciziorcs.classi.raggio.Raggio;
import com.silviolupo.eserciziorcs.classi.ubicazione.Coordinata;
import com.silviolupo.eserciziorcs.classi.ubicazione.Latitudine;
import com.silviolupo.eserciziorcs.classi.ubicazione.Longitudine;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class EserciziorcsApplicazioneTests {

    private Logger logger = LogManager.getLogger(this.getClass());
    private static final Potenza POTENZA_DI_ESEMPIO = new Potenza (1.25);


    // calcolo distanza tra due coordinate : 2 tests

    @Test
    void calcolaDistanzaTraDueCoordinateUguali() {
        Longitudine longitudine = new Longitudine(9.0756298d);
        Latitudine latitudine = new Latitudine(45.4616873d);
        Coordinata coordinata = new Coordinata(longitudine,latitudine);
        double distanza = coordinata.calcolaDistanza(coordinata);
        assertEquals(0.0d,distanza);
    }

    @Test
    void calcolaDistanzaTraDueCoordinateDiverse(){
        Longitudine longitudine = new Longitudine(9.0756298d);
        Latitudine latitudine = new Latitudine(45.4616873d);
        Coordinata coordinata = new Coordinata(longitudine,latitudine);
        Longitudine longitudine2 = new Longitudine(9.0961433d);
        Latitudine latitudine2 = new Latitudine(45.4732446d);
        Coordinata coordinata2 = new Coordinata(longitudine2,latitudine2);
        double distanza = coordinata.calcolaDistanza(coordinata2);
        assertEquals(2.0d,distanza);
    }

    // controllo Latitudine : 3 tests

    @Test
    void costruttoreCorrettoLatitudine() {
        double latitudinePrevista = 0d;
        Latitudine latitudine = new Latitudine(latitudinePrevista);
        assertNotNull(latitudine);
        assertEquals(latitudinePrevista, latitudine.getValore());
    }

    @Test
    void costruttoreNonCorrettoLatitudine() {
        double latitudinePrevista = -97;
        try {
            Latitudine latitudine = new Latitudine(latitudinePrevista);
            assertNotNull(latitudine);
            assertEquals(latitudinePrevista, latitudine.getValore());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            assertTrue(true);
        }
    }

    @Test
    void costruttoreNonCorretto2Latitudine() {
        double latitudinePrevista = 117d;
        try{
            Latitudine longitude = new Latitudine(latitudinePrevista);
            assertNotNull(longitude);
            assertEquals(latitudinePrevista, longitude.getValore());
        } catch (Exception e) {
            logger.fatal(e.getMessage(), e);
            assertFalse(false);

        }}

    // controllo longitudine : 3 tests

    @Test
    void costruttoreCorrettoLongitudine() {
        double longitudinePrevista = 0d;
        Longitudine longitudine = new Longitudine(longitudinePrevista);
        assertNotNull(longitudine);
        assertEquals(longitudinePrevista, longitudine.getValore());
    }

    @Test
    void costruttoreNonCorrettoLongitudine() {
        double longitudinePrevista = -200d;
        try {
            Longitudine longitudine = new Longitudine(longitudinePrevista);
            assertNotNull(longitudine);
            assertEquals(longitudinePrevista, longitudine.getValore());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            assertTrue(true);
        }
        }

        @Test
        void costruttoreNonCorretto2Longitudine() {
            double longitudinePrevista = 181d;
            try{
                Longitudine longitudine = new Longitudine(longitudinePrevista);
                assertNotNull(longitudine);
                assertEquals(longitudinePrevista, longitudine.getValore());
            } catch (Exception e) {
                logger.fatal(e.getMessage(), e);
                assertFalse(false);

            }

        }

    // test ordinaCelleTramiteFrequenza : 1 test

    @Test
    void ordinaCelleTramiteFrequenza() {
        EventoDiCella origine = new EventoDiCella(new Cella("Origine"
                ,new Coordinata(
                new Longitudine(0), new Latitudine(0)))
                , LocalDateTime.now()
                , Tipologia.CONNESSO
        );
        EventoDiCella origineDisconnesso = new EventoDiCella(new Cella("Origine"
                ,new Coordinata(
                new Longitudine(0), new Latitudine(0)))
                , LocalDateTime.now()
                , Tipologia.DISCONNESSO
        );
        EventoDiCella minLatitudine = new EventoDiCella(new Cella("MinLatitudine"
                ,new Coordinata(
                new Longitudine(0), new Latitudine(-70)))
                , LocalDateTime.now()
                , Tipologia.DISCONNESSO
        );
        EventoDiCella minLongitudine = new EventoDiCella(new Cella("MinLongitudine"
                ,new Coordinata(
                new Longitudine(-70), new Latitudine(0)))
                , LocalDateTime.now()
                , Tipologia.CONNESSO
        );
        List<EventoDiCella> list = Arrays.asList(origine
                , minLatitudine
                , origineDisconnesso
                , minLongitudine	);

        SetEventoDiCella setCellEvent = new SetEventoDiCella(list);
        List<String> res = setCellEvent.ordinaCelleMedianteFrequenza();
        assertEquals(list.size(), res.size());

        assertEquals(origine.getNome(), res.get(0));
        assertEquals(origineDisconnesso.getNome(), res.get(1));
        assertEquals(minLongitudine.getNome(), res.get(2));
        assertEquals(minLatitudine.getNome(), res.get(3));
    }

    // test misura forza tramite potenza : 3 tests

    @Test
    void calcolaForzaConPotenzaNelloStessoPunto() {
        MisuraForza misuraForza = new MisuraForzaPotenza(new Cella("cellaConPotenza"
                , new Coordinata(new Longitudine(0) ,  new Latitudine(0) ))
                , POTENZA_DI_ESEMPIO);
        double result = misuraForza.calcola(
                new Coordinata(new Longitudine(0) ,  new Latitudine(0) )
        );
        double expected = 100d;
        assertEquals(expected, result);
    }

    @Test
    void calcolaForzaConPotenzaInPuntiDiversi() {
        MisuraForza misuraForza = new MisuraForzaPotenza(new Cella("cellaConPotenza"
                , new Coordinata(new Longitudine(0), new Latitudine(0) ))
                , POTENZA_DI_ESEMPIO);
        double result = misuraForza.calcola(
                new Coordinata(new Longitudine(10) , new Latitudine(10) )
        );
        double expected = 8.875433827102886E-151;
        assertEquals(expected, result);
    }

    @Test
    void calcolaForzaEsempioDocumentazione() {
        MisuraForza misuraForza = new MisuraForzaPotenza(new Cella("Cella"
                ,new Coordinata(
                new Longitudine(9.0756298), new Latitudine(45.4616873)))
                , POTENZA_DI_ESEMPIO
        );
        double result = misuraForza.calcola(
                new Coordinata(new Longitudine(10), new Latitudine(10)));
        double expected = 0.0;
        assertEquals(expected, result);
    }

    // test misura forza tramite raggio : 3 tests
    @Test
    void calcolaForzaConRaggioNelloStessoPunto() {
        Longitudine zeroLongitude = new Longitudine(0);
        Latitudine zeroLatitude = new Latitudine(0);

        MisuraForza misuraForza = new MisuraForzaRaggio(new Cella("cellNameWithRadius"
                , new Coordinata(zeroLongitude , zeroLatitude ))
                , new Raggio(10d));
        double result = misuraForza.calcola(new Coordinata(zeroLongitude , zeroLatitude ));
        double expected = 100.0d;
        assertEquals(expected, result);
    }


    @Test
    void whenRadiusEqualToTheDistance_thenCalculateZero() {
        MisuraForza misuraForza = new MisuraForzaRaggio(new Cella("cellNameWithRadius"
                , new Coordinata(new Longitudine(0), new Latitudine(0) ))
                , new Raggio(10d));
        double result = misuraForza.calcola(new Coordinata(new Longitudine(10) , new Latitudine(10) ));
        double expected = 0d;
        assertEquals(expected, result);
    }

    @Test
    void whenRadiusMinorThenTheDistance_thenCalculateZero() {
        MisuraForza misuraForza = new MisuraForzaRaggio(new Cella("cellNameWithRadius"
                , new Coordinata(new Longitudine(0), new Latitudine(0) ) )
                , new Raggio(10d));
        double result = misuraForza.calcola(new Coordinata(new Longitudine(2) , new Latitudine(2) ));
        double expected = 0d;
        assertEquals(expected, result);
    }

    @Test
    void whenRadiusByAnalysis_thenCalculateZero() {
        MisuraForza misuraForza = new MisuraForzaRaggio(new Cella("cell2"
                , new Coordinata(new Longitudine(9.0961433), new Latitudine(45.4732446) ) )
                , new Raggio(10d));
        double result = misuraForza.calcola(new Coordinata(new Longitudine(2) , new Latitudine(2) ));
        double expected = 0d;
        assertEquals(expected, result);
    }

}